# ----------------------------------------------------------------------------
# MlengelaDP5
# Programmer: Daudi Mlengela
# Email: dmlengela@cnm.edu
# Purpose: Find the distance between two points (latitude and longitude)
#          expressed in decimal degrees using the haversine formula 
# ----------------------------------------------------------------------------

import math

# ----------------------------------------------------------------------------
# header
# ----------------------------------------------------------------------------

def header():
    print("The purpose of this program is to allow the user to enter the latitude")
    print ("and longitude of two locations in decimal degrees and then calculate the")
    print ("distance between those locations.")

# ----------------------------------------------------------------------------
# get_location
# ----------------------------------------------------------------------------

def get_location():
    latitude = float(input("Enter the latitude value in decimal degrees: "))
    longitude = float(input("Enter longitude value in decimal degrees: "))
    return ([latitude, longitude])

# ----------------------------------------------------------------------------
# calcDistance
# ----------------------------------------------------------------------------

def calcDistance(point1,point2):

    lat1 = point1[0]
    lon1 = point1[1]

    lat2 = point2[0]
    lon2 = point2[1]

    r = 6371000

    r1 = math.radians(lat1)
    r2 = math.radians(lat2)

    a = math.sin(math.radians(lat2 - lat1) / 2.0) ** 2 + \
       math.cos(r1) * math.cos(r2)                    * \
       math.sin(math.radians(lon2 - lon1) / 2.0) ** 2

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    meters = r * c

    return(meters / 1000.0)

# -----------------------------------------------------
# Here are the longitude and latitude values for
# Albuquerque and Santa Fe
# Albuquerque: (35.0844, -106.6504)
# Santa Fe   : (35.6870, -105.9378)
# -----------------------------------------

header()

keepGoing = True

while keepGoing:

   point1 = get_location()
   point2 = get_location()

   d = calcDistance(point1, point2)

   print("The distance between ({0}) and ({1}) is: {2}".format(point1, point2, d))

   answer = input("Would you like to do another?").strip().lower()

   if answer == "" or answer[0] != 'y':
      keepGoing = False

print("Good bye, thank you for using the Geo Points program!")











